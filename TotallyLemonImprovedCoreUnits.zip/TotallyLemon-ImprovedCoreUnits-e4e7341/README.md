# ImprovedCoreUnits
Reduces the bulding damage nerf of the core units 'Alpha, Beta, Gamma' and gives 'Gamma' a set of back weapons that launch fast moving cannon projectiles. 
